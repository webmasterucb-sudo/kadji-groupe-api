export class CreateOffreEmploisDto {}

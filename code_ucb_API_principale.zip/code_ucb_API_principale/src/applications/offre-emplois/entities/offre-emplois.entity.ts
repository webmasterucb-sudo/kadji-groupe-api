export class OffreEmplois {}




// src/travel-tickets/travel-tickets.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TravelTicketsController } from './ceo-office-app.controller';
import { TravelTicketsService } from './ceo-office-app.service';
import { TravelTicket, TravelTicketSchema } from './entities/ceo-office-app.entity';
import { EmployeeController } from './employee.controller';
import { EmployeeService } from './employee.service';
import { Employee, EmployeeSchema } from './entities/employee.entity';


@Module({
  imports: [
    MongooseModule.forFeature([
      { name: TravelTicket.name, schema: TravelTicketSchema },
      { name: Employee.name, schema: EmployeeSchema },
    ])
  ],
  controllers: [TravelTicketsController, EmployeeController],
  providers: [TravelTicketsService, EmployeeService],
})
export class CeoCoreModule {}